ASTER HOME public catalogue (v15)
Upload this folder or ZIP to Netlify Drop.
This is a preview catalogue, NOT a live checkout.
After publication, use the live https:// URL to make a QR code.
